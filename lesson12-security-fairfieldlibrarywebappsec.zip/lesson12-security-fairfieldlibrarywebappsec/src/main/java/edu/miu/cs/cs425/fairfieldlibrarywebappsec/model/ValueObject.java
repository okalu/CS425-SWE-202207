package edu.miu.cs.cs425.fairfieldlibrarywebappsec.model;

public interface ValueObject {
}
