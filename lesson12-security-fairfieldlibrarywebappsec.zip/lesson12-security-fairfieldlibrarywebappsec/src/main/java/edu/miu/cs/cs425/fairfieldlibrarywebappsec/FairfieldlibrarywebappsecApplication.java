package edu.miu.cs.cs425.fairfieldlibrarywebappsec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FairfieldlibrarywebappsecApplication {

    public static void main(String[] args) {
        SpringApplication.run(FairfieldlibrarywebappsecApplication.class, args);
    }

}
