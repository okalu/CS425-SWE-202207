package edu.miu.cs.cs425.fairfieldlibrarywebappsec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FairfieldlibrarywebappsecApplicationTests {

    @Test
    void contextLoads() {
    }

}
